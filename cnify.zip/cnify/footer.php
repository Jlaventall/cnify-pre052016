
<script>


		
    jQuery(document).ready(function() {
        jQuery('nav').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInUp',
            offset: 200
        });

        jQuery('header').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });

        jQuery('content').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });
         jQuery('socialmedia').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });
         jQuery('wwd').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });

         jQuery('makeiteasy').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });
         jQuery('moption').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });

         jQuery('getstarted').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInDown',
            offset: 200
        });

        jQuery('#china').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInUp',
            offset: 200
        });

        jQuery('#china ul li').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated flipInX',
            offset: 200
        });

        jQuery('#china h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInLeft',
            offset: 200
        });

        jQuery('#china p').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInRight',
            offset: 200
        });

        jQuery('#content h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated rubberBand',
            offset: 200
        });

        jQuery('#socialmedia p').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInRight',
            offset: 200
        });

        jQuery('#socialmedia ul li').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInLeft',
            offset: 200
        });

        jQuery('#wwd h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated rubberBand',
            offset: 200
        });

        jQuery('#makeiteasy h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInRight',
            offset: 200
        });

        jQuery('#makeiteasy ul.easy li').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInRight',
            offset: 200
        });

        jQuery('#makeiteasy h3').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInDown',
            offset: 200
        });

        jQuery('#makeiteasy ul.promote li').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInDown  ',
            offset: 200
        });


        jQuery('#moption h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated fadeInUpBig  ',
            offset: 200
        });

        jQuery('#moption p').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceIn  ',
            offset: 200
        });

        jQuery('#moption h4').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated rubberBand',
            offset: 200
        });

        jQuery('#moption ul li img').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated wobble',
            offset: 200
        });

        jQuery('#getstarted h2').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInDown',
            offset: 200
        });

              jQuery('#getstarted .map').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated zoomIn',
            offset: 200
        });

        jQuery('#getstarted table').addClass("hidden").viewportChecker({
            classToAdd: 'visible animated bounceInRight ',
            offset: 200
        });
    });


</script>
</body>
</html>


